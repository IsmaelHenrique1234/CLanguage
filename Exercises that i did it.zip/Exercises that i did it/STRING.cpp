#include <stdio.h>
#include <string.h>
int main () {
   	/*char str1[20], str2[20];
	printf("Digitar String1: ");
	gets(str1);
    printf("Digitar String2: ");
	gets(str2);
	if (!(strcmp(str1,str2)))
	printf("its similar");
	else
	printf("its different");
	*/
	int matriz[5][5] = {{5, 5, 5, 5, 5}, {5, 5, 5, 5, 5}, {5, 5, 5, 5, 5}, {5, 5, 5, 5, 5}, {5, 5, 5, 5, 5}};
	for (int i = 0; i < 5; i++) {
	for (int j = 0; j < 5; j++) 
	printf("%i ", matriz[i][j]);
	printf("\n");
	}
	return 0;
}
