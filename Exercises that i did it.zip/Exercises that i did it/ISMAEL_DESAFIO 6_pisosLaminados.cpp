#include <stdio.h>
#include <locale.h>
int main () {
	setlocale(LC_ALL, "Portuguese_Brazil"); //Colocando Caracteres da nossa lingu� brasileira (UTF-8)
	char YorN; //Sim ou N�o (Escreve com letra Maiuscula)
	int selection; //Variavel de sele��o, Sim ou n�a, Digite Y no ultimo printf para gerar informa��o completa
	//Variaveis de calculos com valores decimais definidos
	float width, length, areaLocal; //Ler Largura em metros e Comprimento em metros, multiplicar para Area local do ambiente em metros quadrados
	float enough, enoughLoss, cost; //Numero suficiente de pe�as, 5% das perdas e o custo total
	float laminA = 0.25, laminB = 0.27, laminC = 0.23, laminD = 0.26, laminE = 0.49; //metros quadrados de cada pe�a
	float priceA = 13.50, priceB = 12.30, priceC = 18.00, priceD = 32.57, priceE = 26.75; //pre�o de cada pe�a
	//Entradas de Comprimento e Saida da �rea do ambiente em m�
	printf("Instala��o de Pisos Laminados!\n\nIremos Solicitar a dimens�es do seu ambiente.\n\n"); //Pulando duas linhas
	printf("Digite a Largura (Em Metros): ");
	scanf("%f", &width);
	printf("Digite o Comprimento (Em Metros): ");
	scanf("%f", &length);
	printf("\n"); //Pulando linha
	
	if (width <= 0 || length <= 0) {
		printf("Valor inv�lido, os valores n�o podem serem negativos ou sem valor!"); //Caso for menor ou igual � zero
	}
	else { //O codigo continua se for falso
		areaLocal = width * length; //calculo da area multiplicando comprimento com largura
		printf("A Dimens�o do ambiente em metros quadrados �: %.2f m�\n\n", areaLocal); //LISTA  DE SELE��O
	    printf("Agora vamos selecionar seu tipo de laminado:\n\n");
		printf("(1)Piso Laminado Clicado Durafloor New Way Nogueira Cadiz\nCada Pe�a: 0,25 m� (1,2m � 0,208m)   Pre�o: R$13,50 por pe�a\n\n");
		printf("(2)Piso Laminado Eucafloor Prime Fresno Decap� New\nCada Pe�a: 0,27 m� (1,36m x 0,197)  Pre�o: R$12,30 por pe�a\n\n");
		printf("(3)Piso Laminado Clicado Quick Step Smart Carvalho Natural Havana com marcas de serra\nCada Pe�a: 0,23 m� (1,2m x 0,19m)  Pre�o: R$18,00 por pe�a\n\n");
		printf("(4)Piso Laminado Clicado Quick Step Impressive Carvalho cinza suave\nCada Pe�a: 0,26 m� (1,38m x 0,19m)  Pre�o: R$32,57 por pe�a\n\n");
		printf("(5)Piso Laminado Click Max Elegance Cadiz Oak\nCada Pe�a: 0,49 m� (1,36m x 0,36m)  Pre�o: R$26,75 por pe�a\n\n");
		printf("Seleciona uns desses pisos pelo n�mero da ordem (1/2/3/4/5): ");
		scanf("%d", &selection); //apenas pode escolher de 1 � 5, caso contrario, vai executar o else
		printf("\n");
		//Calculos de pe�as suficientes com perdas de 5% e valor total do custo para a implanta��o 
		if (selection == 1) { 
			enough = areaLocal / laminA; //metros quadrado dividido pelo metros quadrados do pe�a do piso escolhido
			enoughLoss = (enough * 0.05); //calculo para mostrar 5% das perdas
            cost = (enough + enoughLoss) * priceA; //calculo do custo total, tomando 5% mais o valor orignal multiplicado pelo pre�o
		}
		else if (selection == 2) {
			enough = areaLocal / laminB;
			enoughLoss = (enough * 0.05);
            cost = (enough + enoughLoss) * priceB;
		}
		else if (selection == 3) {
			enough = areaLocal / laminC;
			enoughLoss = (enough * 0.05);
            cost = (enough + enoughLoss) * priceC;
		}
		else if (selection == 4) {
			enough = areaLocal / laminD;
			enoughLoss = (enough * 0.05);
            cost = (enough + enoughLoss) * priceD;
		}
		else if (selection == 5) {
			enough = areaLocal / laminE;
			enoughLoss = (enough * 0.05);
            cost = (enough + enoughLoss) * priceE;
		}
		else {
			printf("Valor Inv�lido! Apenas pode escolher de 1 � 5.");
		} //RESULTADOS FINAIS:
	    printf("Quantidade de pe�as sem perdas: %.2f\n", enough);
	    printf("com margem de 5%% de perdas: %.2f\n", enoughLoss);
	    printf("Soma das pe�as com mais 5%% das perdas: %.2f\n", enoughLoss + enough);
        printf("Custo total: R$ %.2f\n\n", cost);
        printf("Refer�ncia/Site que usei para concluir esse desafio: https://pisoscasa.com.br/ \n");
        printf("Gostaria de ver a refer�ncia completa?(Y / N): ");
        scanf(" %c", &YorN);
        switch (YorN) {
        	case 'Y': {
        		printf("https://pisoscasa.com.br/produto/piso-laminado-clicado-durafloor-new-way-nogueira-cadiz/ \nhttps://pisoscasa.com.br/produto/piso-laminado-colado-eucafloor-prime-fresno-decape-caixa-214-m%c2%b2/ \nhttps://pisoscasa.com.br/produto/piso-laminado-clicado-quick-step-smart-carvalho-natural-havana-com-marcas-de-serra-caixa-228-m%c2%b2/ \nhttps://pisoscasa.com.br/produto/piso-laminado-clicado-quick-step-impressive-carvalho-cinza-suave-caixa-1835-m%c2%b2/ \nhttps://pisoscasa.com.br/produto/piso-laminado-click-max-elegance-cadiz-oak-caixa-387-m%c2%b2/");
				break;
			}	
		
		case 'N': {
			printf("TERMINADO");
			break;
		}
		}
	}
	return 0;
}
