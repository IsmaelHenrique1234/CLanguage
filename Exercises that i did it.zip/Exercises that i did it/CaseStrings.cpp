#include <stdio.h>
#include <string.h>
#include <locale.h>
int main () {
	setlocale(LC_ALL, "Portuguese_Brazil");
	int escolher;
	printf("Os cases seguintes s�o:\n\nCase 1(Ler string e concadenar)\n\nCase 2 (Ler e Inverter)\n\nCase 3(Ler e ver se � pal�ndromo)\n\nCase 4 (Ler substituir)\n\nEscolhe de acordo com os n�meros de 1 � 4:  ");
	scanf("%d", &escolher);
	switch (escolher) {
		case 1: {
			char str1[101], str2[101], str3[101], str4[101], strgato[128];
			fflush(stdin);
			
			printf("\nprimeira string: ");
			scanf("%100[^\n]s", str1);
			fflush(stdin);
			
			
			printf("\nsegunda string: ");
			scanf("%100[^\n]s", str2);
			fflush(stdin);
			
			printf("\nterceira string: ");
			scanf("%100[^\n]s", str3);
			fflush(stdin);
			
			printf("\nquarta string: ");
			scanf("%100[^\n]s", str4);
			fflush(stdin);
			
			strcpy (strgato, "\nConcadena��o foi: ");
			strcat (str3, str4);
			strcat (str2, str3);
			strcat (str1, str2);
			strcat (strgato, str1);
			printf("%s", strgato);
			break;
		}
		case 2: {
			char strNormal[101], strInvertida[101];
			int size, i;
			fflush(stdin);
			
			printf("\nler string: ");
			scanf("%100[^\n]s", &strNormal);
			fflush(stdin);
			
			size = strlen(strNormal);
			
			for (i = 0; i < size; i++) {
				strInvertida[i] = strNormal[size - 1 - i];
			}
			
			strInvertida[size] = '\0';
			
			printf("\nString Invertida: %s ", strInvertida);
			break;
		}
		case 3: {
						char strNormal[101], strInvertida[101];
			int size, i;
			fflush(stdin);
			
			printf("\nler string: ");
			scanf("%100[^\n]s", &strNormal);
			fflush(stdin);
			
			size = strlen(strNormal);
			
			for (i = 0; i < size; i++) {
				strInvertida[i] = strNormal[size - 1 - i];
			}
			
			strInvertida[size] = '\0';
			
			if (!(strcmp(strNormal, strInvertida)))
			printf("\n%s � palindromo ", strInvertida);
		    else
		    printf("\n%s n�o � palindromo ", strNormal);
			break;
		}
		case 4: {
			char string[101];
			char antigo, novo;
			int i;
			fflush(stdin);
			
			printf("\ndigitar string: ");
			fgets(string, 100, stdin);
			fflush(stdin);
			
			printf("\nQual caractere antigo substituir?: ");
			scanf("%c", &antigo);
			fflush(stdin);
			
			printf("\nQual caractere novo colocar?: ");
			scanf("%c", &novo);
			fflush(stdin);
			
			for (i=0; string[i] != '\0'; i++) {
				if (string[i] == antigo) {
					string[i] = novo;
				}
			}
			printf("\nstring novo: %s", string);
			
			break;
		}
		default: {
			printf("Valor incorreto");
			break;
		}
	}
	return 0;
}
