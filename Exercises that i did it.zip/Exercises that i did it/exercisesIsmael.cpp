#include <stdio.h> //ISMAEL HENRIQUE VIEIRA TABORDA e Deus (quer dizer, fiz individualmente)
#include <string.h>//foi usado switch case para a sele��o, if e else na maiora dos exercicios e do_while para repetir o codigo at� que digite 0
#include <locale.h>//no case 6 � a jun��o do exercicio 6 e 7 para codificar e descodificar
int main () {
	setlocale(LC_ALL, "Portuguese_Brazil");
	int selecao;
	do { //ele vai repetir at� que digite zero para sair
	printf("exerc�cios do Ismael, Seleciona de 1 � 6 (0 para sair): "); //CASE 6 � o exercicio 6 e 7 juntos
	scanf("%i", &selecao);
	switch (selecao) {
		case 1: { //saldo medio e oferecer limites de creditos
			float saldoMedio;
			printf("\nDigitar saldo m�dio: ");
			scanf("%f", &saldoMedio);
			if (saldoMedio >= 0 && saldoMedio <= 200) {
				printf("\nNenhum cr�dito\n\n");
			}
			else if (saldoMedio >= 201 && saldoMedio <= 400) {
				printf("\n20%% do valor do saldo m�dio\n\n");
			}
			else if (saldoMedio >= 401 && saldoMedio <= 600) {
				printf("\n30%% do valor do saldo m�dio\n\n");
			}
			else if (saldoMedio >= 601) {
				printf("\n40%% do valor do saldo m�dio\n\n");
			}
			else {
				printf("N�o pode ser negativo\n\n");
			}
			break;
		}
		case 2: { // lista de soma de itens unitarios
			float produtoTotal, cinco = 32.00, seis = 45.00 , dois = 37.00;
			int selecionar;
			printf("\no codigo de tr�s produtos que voc� quer comprar:\n\n5 = R$%.2f\n6 = R$%.2f\n2 = R$%.2f\nquantos produtos voc� quer? (comprar pelo menos dois de acordo com o CODIGO quantas quiser (ex: 562 para pegar todos)): ", cinco, seis, dois);
			scanf("%i", &selecionar);
			if (selecionar == 56 || selecionar == 65) {
				produtoTotal = cinco + seis;
				printf("\nO Total �: R$%.2f\n\n", produtoTotal);
			}
            else if (selecionar == 62 || selecionar == 26) {
			produtoTotal = cinco + seis;
			printf("\nO Total �: R$%.2f\n\n", produtoTotal);
			}
			else if (selecionar == 52 || selecionar == 25) {
			produtoTotal = cinco + dois;
			printf("\nO Total �: R$%.2f\n\n", produtoTotal);
			 }
			else if (selecionar == 562 || selecionar == 256 || selecionar == 652) {
			produtoTotal = cinco + dois + seis;
			printf("\nO Total �: R$%.2f\n\n", produtoTotal);
			 }
			 else {
			 	printf("Valor Invalido");
			 }
			break;
		}
		case 3: { //Lista gigante para somar o total com 4 unidades
			float total, ABCD = 5.30, XYPK = 6.00, KLMP = 3.20, QRST = 2.50;
			int selecao;
		    printf("\n1.'ABCD' = R$%.2f\n2.'XYPK' = R$%.2f\n3.'KLMP' = R$%.2f\n4.'QRST' = R$%.2f\n\nSeleciona de 1 � 4 para somar pelo menos duas (ex: 1234 = ABCD + XYPK + KLMP + QRST): ", ABCD, XYPK, KLMP, QRST);
		    scanf("%i", &selecao);
		    if (selecao == 12 || selecao == 21) {
		    total = ABCD + XYPK;
		    printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 23 || selecao == 32) {
		    total = KLMP + XYPK;
		    printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 34 || selecao == 43) {
			total = KLMP + QRST;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 13 || selecao == 31) {
		    total = ABCD + KLMP;
		    printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 14 || selecao == 41) {
		    total = ABCD + QRST;
		    printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 24 || selecao == 42) {
		    total = XYPK + QRST;
		    printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 123 || selecao == 321 || selecao == 132 || selecao == 312) {
			total = ABCD + XYPK + KLMP;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 234 || selecao == 324 || selecao == 432 || selecao == 342) {
			total = XYPK + KLMP + QRST;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 134 || selecao == 314 || selecao == 431 || selecao == 341) {
			total = ABCD + KLMP + QRST;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 214 || selecao == 124 || selecao == 412 || selecao == 142) {
			total = XYPK + KLMP + QRST;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else if (selecao == 1234 || selecao == 1243 || selecao == 2134 || selecao == 2143 || selecao == 3214 || selecao == 3241 || selecao == 4123 || selecao == 4132 || selecao == 1324 || selecao == 1432 || selecao == 1342) {
			total = ABCD + XYPK + KLMP + QRST;
			printf("\nTotal �: R$%.2f\n\n", total);
			}
			else {
			printf("Valor inv�lido\n");
			}
			break;
		}
		case 4: { //recebe 40% de aumento se o codigo for diferente
    int codigo;
    float salario, salarioNovo, aumento;

    printf("\nDigite o salario do funcionario: ");
    scanf("%f", &salario);

    printf("\nDigite o codigo do cargo:\n\n101-Gerente\n102-Engenheiro\n103-Tecnico\n\nQual escolher?: ");
    scanf("%d", &codigo);
    
        if (codigo == 101)
            aumento = salario * 0.10;
        else if (codigo == 102)
            aumento = salario * 0.20;
        else if (codigo == 103)
            aumento = salario * 0.30;
        else
            aumento = salario * 0.40;
            
    salarioNovo = salario + aumento;
    
    printf("\nSalario antigo: R$%.2f", salario);
    printf("\nNovo salario: R$%.2f", salarioNovo);
    printf("\nDiferenca: R$%.2f\n", aumento);
			break;
		}
		case 5: { //se comprar mais de 12, fica 30 centavos mais barato
			float apple, totalPrice, price;
			printf("\nQuantas ma�as voc� quer comprar? (se comprar mais de doze, recebe desconto de 30 centavos): ");
			scanf("%f", &apple);
			  if (apple < 12)
			   totalPrice = apple * 1.30;
			   else
			   	totalPrice = apple * 1;
			   	
			printf("O Pre�o total �: %.2f\n", totalPrice);
			break;
		}
		case 6: { //Codifica��o e Descodifica��o da Criptografia de C�sar
			char textoSegredo[101];
			int chave;
			fflush(stdin);
			printf("\nCriptografia Cifra de C�sar\n\nDigitar Texto segredo: ");
			scanf("%100[^\n]s", &textoSegredo); //vai ler a string junto com espa�os
			fflush(stdin); //evitar buffer na string
			
			printf("\nDigitar chave do texto segredo: ");
			scanf("%i", &chave);
            fflush(stdin);
		for (int i = 0; textoSegredo[i] != '\0'; i++) {
                textoSegredo[i] = textoSegredo[i] + chave;
          }
          printf("\nTexto criptografado: %s\n", textoSegredo);
          printf("Digite a chave denovo para descodificar: ");
          scanf("%i", &chave);
          fflush(stdin);
    
        for (int i = 0; textoSegredo[i] != '\0'; i++) {
                textoSegredo[i] = textoSegredo[i] - chave;
		}
          printf("\nTexto descriptografado: %s\n\n", textoSegredo);
		  
			break;
		}	
	}
	}
	while (selecao != 0); //ele vai repetir at� que digite zero para sair
	return 0;
}
